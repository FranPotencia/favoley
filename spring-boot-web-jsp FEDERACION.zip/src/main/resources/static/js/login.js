
	$('#listaNavegadorAcceso').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n
	$('#username').on('keypress',function(e) {
	    if(e.which == 13) {
	    	login();
	    }
	});
	$('#password').on('keypress',function(e) {
	    if(e.which == 13) {
	    	login();
	    }
	});
	function login(){
		if($('#username').val()!='' && $('#password').val()!=''){
			var usuario={
					"username":$('#username').val(),
					"password":$('#password').val()
			}
			$.ajax({
				url : "/login",
				data : JSON.stringify(usuario),
				"headers" : {
					"Content-Type" : "application/json"
				},
				method : 'POST',
				async : false,
				success : function(data) {
					if(data!=null && data!=''){
						window.location.href = '/admin?token='+data;
					} else{
						alert('Usuario o contrase�a inv�lidos')
					}
					
				},
				error: function (){
					alert('Usuario o contrase�a inv�lidos')
				}
			});
		} else{
			alert('Introduzca los datos necesarios')
		}
	}
