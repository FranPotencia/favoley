if($('#idEquipo').val()!=null && $('#idEquipo').val()!=''){
		$('#listaNavegadorAdministrador').addClass("activeVerde");
	} else{
		$('#listaNavegadorEquipo').addClass("activeVerde");
	}

	var idJugador = 0;

	function getBase64(file) {
// 		var reader = new FileReader();
// 		reader.readAsDataURL(file);
// 		reader.onload = function() {
// 			postEquipoParam(reader.result)
// 		};
// 		reader.onerror = function(error) {
			postEquipoParam('');
// 		};
	}
	function postEquipo() {
// 		var file = $('#escudo')[0].files[0];
// 		getBase64(file); // prints the base64 string
		getBase64(''); 
	}

	//Jugador nuevo, inexistente en la base de datos
	function addJugador() {
		idJugador++;
		$('#tablaJugadores tbody')
				.append(
						'<tr class="filasNuevas" id="jugador'+idJugador+'">'
								+ '<td><input id="nombre'+idJugador+'" class="form-control input-sm"  type="text"></td>'
								+ '<td><input id="apellidos'+idJugador+'" class="form-control input-sm" type="text"></td>'
								+ '<td><input id="dni'+idJugador+'" class="form-control input-sm" type="text"></td>'
								+ '<td><input id="fecha'+idJugador+'" class="form-control input-sm" type="date"></td>'
								+ '<td> <button type="button" class="btn btn-danger btn-sm"  onclick="deleteJugador(\''
								+ idJugador + '\')" >Eliminar</button>'
								+ '</div>' + '</div>' + '</div>'
								+ '</div></td>' + '</tr>')
	}

	function deleteJugador(id) {
		$('#jugador' + id).remove();
	}

	function postEquipoParam(foto) {

		//Jugadores que ya se encuentran en la base de datos, y ya tienen un ID real.
		var filasReales = $('.filasReal'); // .filasReal hace llamada a todos los elementos que pertenecen a esa clase
		var jugadores = []; //Creo una tabla en la que voy a introducir tanto los jugadores antiguos como los nuevos(en este caso los antiguos)
		for (var i = 0; i < filasReales.length; i++) {
			var item = filasReales[i].id.split('jugadorReal')[1]; //Extraigo el id de su base de datos, para que se actualicen los posibles cambios "Francisco Barbosa Mar�n" .split(" ") ["Francisco","Barbosa","MAr�n"]
			
			if($('#nombreReal' + item).val()==''){
				alert('Falta nombre');
				return ;
			}
			if($('#apellidosReal' + item).val()==''){
				alert('Falta apellidos');
				return ;
			}
			if($('#dniReal' + item).val()==''){
				alert('Falta dni');
				return ;
			}
			if($('#fechaReal' + item).val()==''){
				alert('Falta fecha de nacimiento');
				return ;
			}
			var jugador = {
				"id" : item,
				"nombre" : $('#nombreReal' + item).val(),
				"apellidos" : $('#apellidosReal' + item).val(),
				"dni" : $('#dniReal' + item).val(),
				"fechaNacimiento" : $('#fechaReal' + item).val()
			}
			jugadores.push(jugador); //Guardo en la tabla los jugadores antiguos
		}

		//Jugadores nuevos que no se encontraban en la base de datos
		var filasNuevas = $('.filasNuevas'); //#id .class 
		var listJugadores = []; // creo que esta no se usa y se puede eliminar
		for (var i = 0; i < filasNuevas.length; i++) {

			// 			var idFila=filasNuevas[i].id;// jugador1
			// 			var array=idFila.split('jugador'); // ["","1"]
			// 			var item=array[1];// 1		
			//			Esto es igual que la l�nea siguiente:

			var item = filasNuevas[i].id.split('jugador')[1];
			if($('#nombre' + item).val()==''){
				alert('Falta nombre');
				return ;
			}
			if($('#apellidos' + item).val()==''){
				alert('Falta apellidos');
				return ;
			}
			if($('#dni' + item).val()==''){
				alert('Falta dni');
				return ;
			}
			if($('#fecha' + item).val()==''){
				alert('Falta fecha de nacimiento');
				return ;
			}
			
			// Aqui igual
			var jugador = {
				"id" : null,
				"nombre" : $('#nombre' + item).val(),
				"apellidos" : $('#apellidos' + item).val(),
				"dni" : $('#dni' + item).val(),
				"fechaNacimiento" : $('#fecha' + item).val()
			}
			jugadores.push(jugador); //a�ado estos jugadores a la lista general
		}

		var idEquipo = null;
		if ($('#idEquipo').val() != '') { //Si el equipo no ha sido creado, se le crear� un ID cuando sea introducido en la base de datos, si el equipo es actualizado, pillaremos el ID del principio, para que su modificaci�n sea correcta.
			idEquipo = $('#idEquipo').val();
		}
		
		if(jugadores.length<6){
			alert('Hacen falta inscribir al menos 6 jugadores.');
			return ;
		}
		// comprobar todos los campos de equipo menos idEquipo
		var equipo = {
			"id" : idEquipo,
			"nombreEquipo" : $('#nombreEquipo').val(),
			"localidad" : $('#localidad').val(),
			"provincia" : $('#provincia').val(),
			"direccion" : $('#direccion').val(),
			"pabellon" : $('#pabellon').val(),
			"email" : $('#email').val(),
			"movil" : $('#movil').val(),
			"primerEntrenador" : $('#primerEntrenador').val(),
			"photoString" : foto,
			"jugadores" : jugadores
		};
		if ($('#idEquipo').val() != '') { //Si el equipo no ha sido creado, se le crear� un ID cuando sea introducido en la base de datos, si el equipo es actualizado, pillaremos el ID del principio, para que su modificaci�n sea correcta.
			$.ajax({
				url : '/admin/peticionActualizarEquipo?token='+$("#token").val(),
				method : 'POST',
				data : JSON.stringify(equipo),
				"headers" : {
					"Content-Type" : "application/json"
				},
				success : function(response) {
// 					if (foto == '') {
// 						alert('Equipo guardado sin escudo');
// 					}
					alert('Equipo guardado');
				},
				error : function() {
					alert('No se ha podido guardar el equipo');
				}
			});
		} else{
			$.ajax({
				url : '/guardarEquipo',
				method : 'POST',
				data : JSON.stringify(equipo),
				"headers" : {
					"Content-Type" : "application/json"
				},
				success : function(response) {
// 					if (foto == '') {
// 						alert('Equipo creado sin escudo');
// 					}
					location.href = "/";
				},
				error : function() {
					alert('No se ha podido guardar el equipo');
				}
			});
		}
		
	}

	//Jugadores ya existentes
	function addJugadorReal(response) {
		$('#tablaJugadores tbody')
				.append(
						'<tr class="filasReal" id="jugadorReal'+response.id+'">'
								+ '<td><input id="nombreReal'+response.id+'" class="form-control input-sm"  type="text" value="'+response.nombre+'"></td>'
								+ '<td><input id="apellidosReal'+response.id+'" class="form-control input-sm" type="text" value="'+response.apellidos+'"></td>'
								+ '<td><input id="dniReal'+response.id+'" class="form-control input-sm" type="text" value="'+response.dni+'"></td>'
								+ '<td><input id="fechaReal'+response.id+'" class="form-control input-sm" type="date" value="'+response.fechaNacimientoFormateada+'" ></td>'
								+ '<td><button type="button" onclick="deleteJugadorReal(\''
								+ response.id
								+ '\')" '
								+ ' class="btn btn-danger btn-sm">Eliminar</button></td>'
								+ '</tr>')
	}

	function deleteJugadorReal(id) {
		$('#jugadorReal' + id).remove();
	}

	function getEquipo() {
		if ($('#idEquipo').val() != '') {
			$.ajax({
				url : '/admin/getEquipoConfirmado/' + $('#idEquipo').val()+'?token='+$("#token").val(),
				method : 'GET',
				success : function(response) {
					$('#nombreEquipo').val(response.nombreEquipo);
					$('#localidad').val(response.localidad);
					$('#provincia').val(response.provincia);
					$('#direccion').val(response.direccion);
					$('#pabellon').val(response.pabellon);
					$('#email').val(response.email);
					$('#movil').val(response.movil);
					$('#primerEntrenador').val(response.primerEntrenador);
					$('#escudo').val(response.escudo);

					//Cuando muestro un equipo, a�ado a la vista todos los jugadores que pertenecen a un equipo, llamando a la funci�n addJugadorReal
					for (var i = 0; i < response.jugadores.length; i++) {
						addJugadorReal(response.jugadores[i]);
					}
				},
				error : function() {
					alert('Error inesperado');
				}
			});
		}
	}

	getEquipo();

