
	$('#listaNavegadorInicio').addClass("activeVerde");
	
function jornadaProxima(){
	$.ajax({
		url : '/getJornadaProxima',
		method : 'GET',
		success : function(response) {
			if(response!=null){
				$('#divFechaJornada').append('<label>'+response.fechaJornada+'</label>')
				$('#jornadaProxima').append(
						'<table id="tablaJornadaProxima" class="table">'
						+ '<thead>' + '<tr>'
						+ '<th>Equipo local</th>'
						+ '<th>Resultado</th>' + '</tr>'
						+ '<th>Equipo visitante</th>'
						+ '</thead>' + '<tbody>'
						+ '</tbody>' + '</table>');
				var tablaJornadaProxima=$('#tablaJornadaProxima').DataTable({"paging" : false, "responsive" : true,
					"lengthChange": false,"info": false,"searching":false,"ordering": false,"columns": [
						{ "orderable": false },
					    { "orderable": false },
					    { "orderable": false }
					   
					  ],"language": {
				            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
				        }});
				for (var i = 0; i < response.listaPartidoDTO.length; i++) {
					var rowNode = tablaJornadaProxima
				    .row.add( [ response.listaPartidoDTO[i].local, response.listaPartidoDTO[i].resultado, 
				    	response.listaPartidoDTO[i].visitante] )
				    .draw()
				    .node();
				}
			}
		}
	});
}
jornadaProxima();