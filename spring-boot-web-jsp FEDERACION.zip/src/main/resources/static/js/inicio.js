
	$('#listaNavegadorInicio').addClass("activeVerde");
	
function jornadaProxima(){
	$.ajax({
		url : '/getJornadaProxima',
		method : 'GET',
		success : function(response) {
			if(response!=null){
				if(response.fechaJornada!=null){
					$('#divFechaJornada').append('<label>'+response.fechaJornada+'</label>')
				}
				if(response.listaPartidoDTO!=null && response.listaPartidoDTO.length>0){
					$('#jornadaProxima').append(
							'<table id="tablaJornadaProxima" class="table">'
							+ '<thead> <tr>'
							+ '<th style="text-align: center;">Equipo local</th>'
							+ '<th style="text-align: center;">Resultado</th> '
							+ '<th style="text-align: center;">Equipo visitante</th></tr>'
							+ '</thead> <tbody>'
							+ '</tbody> </table>');
					var tablaJornadaProxima=$('#tablaJornadaProxima').DataTable({"paging" : false, "responsive" : true,
						"lengthChange": false,"info": false,"searching":false,"ordering": false,"columns": [
							{ "orderable": false },
						    { "orderable": false },
						    { "orderable": false }
						   
						  ],"language": {
					            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
					        }});
					
					for (var i = 0; i < response.listaPartidoDTO.length; i++) {
						var rowNode = tablaJornadaProxima
					    .row.add( [ response.listaPartidoDTO[i].local, response.listaPartidoDTO[i].resultado, 
					    	response.listaPartidoDTO[i].visitante] )
					    .draw()
					    .node();
					}
					$('td').css('text-align','center');
				}
			}
		}
	});
}
jornadaProxima();