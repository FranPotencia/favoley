
	$('#listaNavegadorAdministrador').addClass("activeVerde")
	var tablaEquipos = $('#tablaEquipos').DataTable({"paging" : true, "responsive" : true,"pageLength" : 5,
		"lengthChange": false,"info": false,"ordering":false,"columns": [
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false }
		  ],"language": {
	            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	        }});
	function getEquipos() {
		$.ajax({
			url : '/admin/getEquiposActualizar?token='+$('#token').val(),
			method : 'GET',
			success : function(response) { //response manda una tabla con equipos

				for (var i = 0; i < response.length; i++) {
					var rowNode = tablaEquipos
				    .row.add( [ response[i].nombreEquipo, response[i].localidad, 
				    	response[i].provincia,response[i].direccion,response[i].pabellon,response[i].email,response[i].movil,
				    	response[i].primerEntrenador,'<button type="button" onclick="editarEquipo(\''+response[i].id+'\')" '
						+'  class="btn btn-info btn-sm">Ver detalles</button>'] )
				    .draw()
				    .node();

				}
			},
			error : function() {
				alert('Error inesperado');
			}
		});
	}
	function editarEquipo(id){
		location.href='/admin/actualizarEquipo/'+id+'?token='+$("#token").val();
	}
	getEquipos();
