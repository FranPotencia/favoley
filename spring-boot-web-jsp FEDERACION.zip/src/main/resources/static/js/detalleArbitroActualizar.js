
	
	$('#listaNavegadorAdministrador').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n
   
	
	function postArbitro() {

		$.ajax({
			url : '/admin/aceptarArbitroActualizado/'+$('#idArbitro').val()+'?token='+$('#token').val(),
			method : 'POST',
			//data : JSON.stringify(equipo), No se lo mando, ya que el equipo ya se encuentra en la base de datos, s�lo necesita el id que le mando por la url
			"headers" : {
				"Content-Type" : "application/json"
			},
			success : function(response) {
				location.href = '/admin/listaArbitros?token='+$('#token').val();
			},
			error : function() {
				alert('No se ha podido guardar el arbitro');
			}
		});

	}
	
	

	
	function getArbitro(){
		if($('#idArbitro').val()!=''){
			$.ajax({
				url : '/admin/getArbitroConfirmado/'+$('#idArbitro').val()+'?token='+$('#token').val(),
				method : 'GET',
				success : function(response) {
					$('#nombre').val(response.nombre);
					$('#apellidos').val(response.apellidos);
					$('#dni').val(response.dni);
					$('#localidad').val(response.localidad);
					$('#provincia').val(response.provincia);
					$('#licencia').val(response.licencia);
					$('#fechaNacimiento').val(response.fechaNacimientoFormateada);
					$('#delegacion').val(response.delegacion);
					$('#email').val(response.email);
					$('#movil').val(response.movil);
					$('#numeroLicencia').val(response.numeroLicencia);
					
				},
				error : function(response) {
					alert('Error inesperado');
				}
			});
		}
	}
	
	function getArbitroActualizado(){
		if($('#idArbitro').val()!=''){
			$.ajax({
				url : '/admin/getArbitroActualizado/'+$('#idArbitro').val()+'?token='+$('#token').val(),
				method : 'GET',
				success : function(response) {
					$('#nombreActualizado').val(response.nombre);
					$('#apellidosActualizado').val(response.apellidos);
					$('#dniActualizado').val(response.dni);
					$('#localidadActualizado').val(response.localidad);
					$('#provinciaActualizado').val(response.provincia);
					$('#licenciaActualizado').val(response.licencia);
					$('#fechaNacimientoActualizado').val(response.fechaNacimientoFormateada);
					$('#delegacionActualizado').val(response.delegacion);
					$('#emailActualizado').val(response.email);
					$('#movilActualizado').val(response.movil);
					$('#numeroLicenciaActualizado').val(response.numeroLicencia);
					
				},
				error : function(response) {
					alert('Error inesperado');
				}
			});
		}
	}
	
	function deleteArbitro(id){
		$.ajax({
			url : '/admin/deleteArbitro/'+id+'?token='+$('#token').val(),
			method:'DELETE',
			success : function(response) {
				location.href = '/admin/getArbitros?token='+$('#token').val();
			},
			error: function(response) {
				alert('Ha ocurrido un error')
			}
		});
	}
	
	getArbitro();
	getArbitroActualizado();

