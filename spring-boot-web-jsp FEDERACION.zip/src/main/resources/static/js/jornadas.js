
	$('#listaNavegadorCompeticion').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n

	var tablaClasificacion=$('#tablaClasificacion').DataTable({"paging" : false, "responsive" : true,
		"lengthChange": false,"info": false,"searching":false,"ordering": false,"columns": [
		    { "orderable": false,"width": "10%" },
		    { "orderable": false,"width": "50%" },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false }
		  ],"language": {
	            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	        }});
	
	function getClasificacion(){
		$.ajax({
			url : '/getClasificacion',
			method : 'GET',
			success : function(response) {
				if (response != null && response.length > 0) {
					for (var i = 0; i < response.length; i++) {
						var rowNode = tablaClasificacion
					    .row.add( [ response[i].posicion, response[i].nombre, response[i].partidosJugados,
					    	response[i].partidosGanados,response[i].partidosPerdidos,response[i].tanteosFavor,
					    	response[i].tanteosContra,response[i].puntos] )
					    .draw()
					    .node();
					}
				}
			},
			error: function(){
				alert('Ha ocurrido un error consultando clasificaci�n')	;	
			}
		})
	}
		
	function getJornadas() {
		$.ajax({
					url : '/getJornadas',
					method : 'GET',
					success : function(response) {

						if (response != null && response.length > 0) {
							$('#listaJornadas').append(
									'<option onchange=traeJornada("'
											+ response[0].id + '") value="'
											+ response[0].id + '">'
											+ response[0].numeroJornada
											+ '</option>');
							$('#divFechaJornada').append('<label class="classHidden" style="margin-top: 5px;" id="fechaJornada'+response[0].id+'">'+response[0].fechaJornadaFormateada+'</label>')
							$('#divTablaJornada').append(
									'<table id="tablaPartidosJornada'+response[0].id+'" class="table classHidden">'
											+ '<thead>' + '<tr>'
											+ '<th>N&deg; partido</th>'
											+ '<th>Equipo local</th>'
											+ '<th>Equipo visitante</th>'
											+ '<th>Set 1</th>'
											+ '<th>Set 2</th>'
											+ '<th>Set 3</th>'
											+ '<th>Set 4</th>'
											+ '<th>Set 5</th>'
											+ '<th>Resultado</th>' + '</tr>'
											+ '</thead>' + '<tbody>'
											+ '</tbody>' + '</table>');
							var tablaJornada=$('#tablaPartidosJornada'+response[0].id).DataTable({"paging" : false, "responsive" : true,
								"lengthChange": false,"info": false,"searching":false,"ordering": false,"columns": [
									{ "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false }
								   
								  ],"language": {
							            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
							        }});
							
							for (var j = 0; j < response[0].partidos.length; j++) {
								var resultado;
								if (response[0].partidos[j].equipoLocal == 'Descansa'
										|| response[0].partidos[j].equipoVisitante == 'Descansa'
										|| response[0].partidos[j].resultado == null) {
									resultado = '-';
								} else {
									resultado = response[0].partidos[j].resultado;
								}
								var set1="";
								var set2="";
								var set3="";
								var set4="";
								var set5="";
								if(response[0].partidos[j].set1!=null){
									set1=response[0].partidos[j].set1;
								}
								if(response[0].partidos[j].set2!=null){
									set2=response[0].partidos[j].set2;
								}
								if(response[0].partidos[j].set3!=null){
									set3=response[0].partidos[j].set3;
								}
								if(response[0].partidos[j].set4!=null){
									set4=response[0].partidos[j].set4;
								}
								if(response[0].partidos[j].set5!=null){
									set5=response[0].partidos[j].set5;
								}
								var rowNode = tablaJornada
							    .row.add( [ response[0].partidos[j].numeroPartido, response[0].partidos[j].equipoLocal, 
							    	response[0].partidos[j].equipoVisitante,set1,set2,set3,set4,set5,resultado] )
							    .draw()
							    .node();

							}
						}
						for (var i = 1; i < response.length; i++) {
							$('#listaJornadas').append(
									'<option value="'+response[i].id+'">'
											+ response[i].numeroJornada
											+ '</option>');
							$('#divFechaJornada').append('<label hidden="true" class="classHidden" style="margin-top: 5px;" id="fechaJornada'+response[i].id+'">'+response[i].fechaJornadaFormateada+'</label>')
							$('#divTablaJornada')
									.append(
											'<table hidden="true" id="tablaPartidosJornada'+response[i].id+'" class="table classHidden">'
													+ '<thead>'
													+ '<tr>'
													+ '<th>N� partido</th>'
													+ '<th>Equipo local</th>'
													+ '<th>Equipo visitante</th>'
													+ '<th>Set 1</th>'
													+ '<th>Set 2</th>'
													+ '<th>Set 3</th>'
													+ '<th>Set 4</th>'
													+ '<th>Set 5</th>'
													+ '<th>Resultado</th>'
													+ '</tr>'
													+ '</thead>'
													+ '<tbody>'
													+ '</tbody>'
													+ '</table>');
							var tablaJornada=$('#tablaPartidosJornada'+response[i].id).DataTable({"paging" : false, "responsive" : true,
								"lengthChange": false,"info": false,"searching":false,"ordering": false,"columns": [
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false },
								    { "orderable": false }
								   
								  ],"language": {
							            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
							        }});
							for (var j = 0; j < response[i].partidos.length; j++) {
								var resultado;
								if (response[i].partidos[j].equipoLocal == 'Descansa'
										|| response[i].partidos[j].equipoVisitante == 'Descansa'
										|| response[i].partidos[j].resultado == null) {
									resultado = '-';
								} else {
									resultado = response[i].partidos[j].resultado;
								}
								var set1="";
								var set2="";
								var set3="";
								var set4="";
								var set5="";
								if(response[i].partidos[j].set1!=null){
									set1=response[i].partidos[j].set1;
								}
								if(response[i].partidos[j].set2!=null){
									set2=response[i].partidos[j].set2;
								}
								if(response[i].partidos[j].set3!=null){
									set3=response[i].partidos[j].set3;
								}
								if(response[i].partidos[j].set4!=null){
									set4=response[i].partidos[j].set4;
								}
								if(response[i].partidos[j].set5!=null){
									set5=response[i].partidos[j].set5;
								}
								var rowNode = tablaJornada
							    .row.add( [ response[i].partidos[j].numeroPartido, response[i].partidos[j].equipoLocal, 
							    	response[i].partidos[j].equipoVisitante,set1,set2,set3,set4,set5,resultado] )
							    .draw()
							    .node();
							}
						}
					},
					error : function() {
						alert('Error inesperado');
					}
				});

	}
	$('#listaJornadas').on('change', function() {
		$('.classHidden').hide();
		$('#fechaJornada' + $(this).val()).show();
		$('#tablaPartidosJornada' + $(this).val()).show();
	});
	
	getJornadas();
	getClasificacion();

