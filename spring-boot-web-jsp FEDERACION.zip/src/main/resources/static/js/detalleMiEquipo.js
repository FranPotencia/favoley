
	
	$('#listaNavegadorAdministrador').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n
   
	
	function postEquipo() {

// 		$.ajax({
// 			url : '/admin/aceptarEquipo/'+$('#idEquipo').val()+'?token='+$('#token').val(),
// 			method : 'POST',
// 			//data : JSON.stringify(equipo), No se lo mando, ya que el equipo ya se encuentra en la base de datos, s�lo necesita el id que le mando por la url
// 			"headers" : {
// 				"Content-Type" : "application/json"
// 			},
// 			success : function(response) {
// 				location.href = "/admin/equipos?token="+$('#token').val();
// 			},
// 			error : function() {
// 				alert('No se ha podido guardar el equipo');
// 			}
// 		});

	}
	
	//Jugadores ya existentes
	function addJugadorReal(response) {
		$('#tablaJugadores tbody').append(
						'<tr>'
						+ '<td>'+response.nombre+'</td>'
						+ '<td>'+response.apellidos+'</td>'
						+ '<td>'+response.dni+'</td>'
						+ '<td>'+response.fechaNacimientoFormateada+'</td>'
						+ '<td><button type="button" class="btn btn-danger" >Eliminar</button></td>'
						+ '</tr>')
	}
	

	
	function getEquipo(){
		if($('#idEquipo').val()!=''){
			$.ajax({
				url : '/admin/getEquipoConfirmado/'+$('#idEquipo').val()+'?token='+$('#token').val(),
				method : 'GET',
				success : function(response) {
					$('#nombreEquipo').val(response.nombreEquipo);
					$('#localidad').val(response.localidad);
					$('#provincia').val(response.provincia);
					$('#direccion').val(response.direccion);
					$('#pabellon').val(response.pabellon);
					$('#email').val(response.email);
					$('#movil').val(response.movil);
					$('#primerEntrenador').val(response.primerEntrenador);
					$('#escudo').val(response.escudo);
					
					//Cuando muestro un equipo, a�ado a la vista todos los jugadores que pertenecen a un equipo, llamando a la funci�n addJugadorReal
					for (var i = 0; i < response.jugadores.length; i++) {
						addJugadorReal(response.jugadores[i]);
					}
				},
				error : function() {
					alert('Error inesperado');
				}
			});
		}
		
	}
	
	function deleteEquipo(id){
		$.ajax({
			url : '/admin/deleteEquipo/'+id+'?token='+$('#token').val(),
			method:'DELETE',
			success : function(response) {
				location.href = "/admin/equipos?token="+$('#token').val();
			},
			error: function(response) {
				alert('Ha ocurrido un error')
			}
		});
	}
	
	getEquipo();

