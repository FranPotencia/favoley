
	$('#listaNavegadorAdministrador').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n

	$('#botonGuardarPartido').on('click', function(){
		var partidoDTO={
			"numeroPartido":$('#numeroPartidoIngresar').val(),
			"set1Local":$('#set1Local').val(),
			"set1Visitante":$('#set1Visitante').val(),
			"set2Local":$('#set2Local').val(),
			"set2Visitante":$('#set2Visitante').val(),
			"set3Local":$('#set3Local').val(),
			"set3Visitante":$('#set3Visitante').val(),
			"set4Local":$('#set4Local').val(),
			"set4Visitante":$('#set4Visitante').val(),
			"set5Local":$('#set5Local').val(),
			"set5Visitante":$('#set5Visitante').val(),
			"resultadoLocal":$('#resultadoLocal').val(),
			"resultadoVisitante":$('#resultadoVisitante').val()
		}
		$.ajax({
			url : '/admin/guardarPartido?token='
					+ $('#token').val(),
			method : 'POST',
			data : JSON.stringify(partidoDTO),
			"headers" : {
				"Content-Type" : "application/json"
			},
			success : function(response) {
				alert('Resultados ingresados correctamente');
				location.reload();
			},
			error : function(response) {
				alert(response.responseJSON.error);
			}
		});
	})
	var tablaPartidos = $('#tablaPartidos').DataTable({"paging" : true, "responsive" : true,"pageLength" : 3,
		"lengthChange": false,"info": false,"columns": [
		    { "orderable": true },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false }
		  ],"language": {
	            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	        }});
	function getPartidosArbitro() {
		$
				.ajax({
					url : '/admin/getPartidosArbitro/?token='
							+ $('#token').val(),
					method : 'GET',
					success : function(response) {
						if (response != null && response.length > 0) {
							for (var i = 0; i < response.length; i++) {
								var set1 = "";
								var set2 = "";
								var set3 = "";
								var set4 = "";
								var set5 = "";
								var resultadoFinal = "";
								if (response[i].set1 != null) {
									set1 = response[i].set1;
								}
								if (response[i].set2 != null) {
									set2 = response[i].set2;
								}
								if (response[i].set3 != null) {
									set3 = response[i].set3;
								}
								if (response[i].set4 != null) {
									set4 = response[i].set4;
								}
								if (response[i].set5 != null) {
									set5 = response[i].set5;
								}
								if (response[i].resultado != null) {
									resultadoFinal = response[i].resultado;
								}
								if (response[i].resultado != null) {
									var rowNode = tablaPartidos
								    .row.add( [ response[i].numeroPartido, response[i].equipoLocal, response[i].equipoVisitante,
								    	response[i].pabellon,set1,set2,set3,set4,set5,resultadoFinal,'<label>Partido finalizado</label>'] )
								    .draw()
								    .node();
// 									$('#tablaPartidos tbody')
// 											.append(
// 													'<tr id="filaPartido'+i+'">'
// 															+ '<td>'
// 															+ response[i].numeroPartido
// 															+ '</td>'
// 															+ '<td>'
// 															+ response[i].equipoLocal
// 															+ '</td>'
// 															+ '<td>'
// 															+ response[i].equipoVisitante
// 															+ '</td>'
// 															+ '<td>'
// 															+ response[i].pabellon
// 															+ '</td>'
// 															+ '<td>'
// 															+ set1
// 															+ '</td>'
// 															+ '<td>'
// 															+ set2
// 															+ '</td>'
// 															+ '<td>'
// 															+ set3
// 															+ '</td>'
// 															+ '<td>'
// 															+ set4
// 															+ '</td>'
// 															+ '<td>'
// 															+ set5
// 															+ '</td>'
// 															+ '<td>'
// 															+ resultadoFinal
// 															+ '</td>'
// 															+ '<td><label>Partido finalizado</label></td>'
// 															+ '</tr>');
								} else {
									
									var rowNode = tablaPartidos
								    .row.add( [ response[i].numeroPartido, response[i].equipoLocal, response[i].equipoVisitante,
								    	response[i].pabellon,set1,set2,set3,set4,set5,resultadoFinal,'<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal" id="ingresarResultado'+i+'" >Ingresar resultados</button>'] )
								    .draw()
								    .node();
									
// 									$('#tablaPartidos tbody')
// 											.append(
// 													'<tr id="filaPartido'+i+'">'
// 															+ '<td>'
// 															+ response[i].numeroPartido
// 															+ '</td>'
// 															+ '<td>'
// 															+ response[i].equipoLocal
// 															+ '</td>'
// 															+ '<td>'
// 															+ response[i].equipoVisitante
// 															+ '</td>'
// 															+ '<td>'
// 															+ response[i].pabellon
// 															+ '</td>'
// 															+ '<td>'
// 															+ set1
// 															+ '</td>'
// 															+ '<td>'
// 															+ set2
// 															+ '</td>'
// 															+ '<td>'
// 															+ set3
// 															+ '</td>'
// 															+ '<td>'
// 															+ set4
// 															+ '</td>'
// 															+ '<td>'
// 															+ set5
// 															+ '</td>'
// 															+ '<td>'
// 															+ resultadoFinal
// 															+ '</td>'
// 															+ '<td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal" id="ingresarResultado'+i+'" >Ingresar resultados</button></td>'
// 															+ '</tr>');
									$('#ingresarResultado' + i)
											.on(
													'click',
													function() {
														$('#numeroPartidoIngresar').val($(this)
																				.parent()
																				.parent()
																				.children()[0].innerHTML);
														$('#equipoLocalIngresar').html($(this)
																.parent()
																.parent()
																.children()[1].innerHTML);
														$('#equipoVisitanteIngresar').html($(this)
																.parent()
																.parent()
																.children()[2].innerHTML);
														
														

													})
								}
							}

						}
					},
					error : function() {
						alert('No se ha podido guardar el árbitro');
					}
				});
	}

	function postActualizar() {

		if($('#nombre').val()==''){
			alert('Falta nombre');
			return ;
		}
		if($('#apellidos').val()==''){
			alert('Falta apellidos');
			return ;
		}
		if($('#dni').val()==''){
			alert('Falta dni');
			return ;
		}
		if($('#fechaNacimiento').val()==''){
			alert('Falta fecha de nacimiento');
			return ;
		}
		if($('#localidad').val()==''){
			alert('Falta localidad');
			return ;
		}
		if($('#provincia').val()==''){
			alert('Falta provincia');
			return ;
		}
		if($('#email').val()==''){
			alert('Falta email');
			return ;
		}
		if($('#movil').val()==''){
			alert('Falta movil');
			return ;
		}
		if($('#delegacion').val()==''){
			alert('Falta delegacion');
			return ;
		}
		if($('#licencia').val()==''){
			alert('Falta licencia');
			return ;
		}
		if($('#numeroLicencia').val()==''){
			alert('Falta numeroLicencia');
			return ;
		}
		
		var arbitro = {
			"nombre" : $('#nombre').val(),
			"apellidos" : $('#apellidos').val(),
			"dni" : $('#dni').val(),
			"fechaNacimiento" : $('#fechaNacimiento').val(),
			"localidad" : $('#localidad').val(),
			"provincia" : $('#provincia').val(),
			"email" : $('#email').val(),
			"movil" : $('#movil').val(),
			"delegacion" : $('#delegacion').val(),
			"licencia" : $('#licencia').val(),
			"numeroLicencia" : $('#numeroLicencia').val()
		}

		$.ajax({
			url : '/admin/peticionActualizarArbitro/?token='
					+ $('#token').val(),
			method : 'POST',
			data : JSON.stringify(arbitro),
			"headers" : {
				"Content-Type" : "application/json"
			},
			success : function(response) {
				alert('Solicitud de cambio enviada');
			},
			error : function() {
				alert('No se ha podido guardar el árbitro');
			}
		});

	}

	function getArbitro() {
		if ($('#idArbitro').val() != '') {
			$.ajax({
				url : '/admin/getArbitroConfirmado/' + $('#idArbitro').val()
						+ '?token=' + $('#token').val(),
				method : 'GET',
				success : function(response) {
					$('#nombre').val(response.nombre);
					$('#apellidos').val(response.apellidos);
					$('#dni').val(response.dni);
					$('#localidad').val(response.localidad);
					$('#provincia').val(response.provincia);
					$('#licencia').val(response.licencia);
					$('#fechaNacimiento').val(response.fechaNacimientoFormateada);
					$('#delegacion').val(response.delegacion);
					$('#email').val(response.email);
					$('#movil').val(response.movil);
					$('#numeroLicencia').val(response.numeroLicencia);

				},
				error : function(response) {
					alert('Error inesperado');
				}
			});
		}
	}

	function postUsuario() {

		var usuario = {
			"username" : $('#username').val(),
			"password" : $('#password').val()
		};

		$.ajax({
			url : '/admin/cambiarPassword?token=' + $('#token').val(),
			method : 'POST',
			data : JSON.stringify(usuario),
			"headers" : {
				"Content-Type" : "application/json"
			},
			success : function(response) {
				$('#username').val(response.username);
				$('#password').val(response.password);
				alert('Contrase�a actualizada');
			},
			error : function() {
				alert('No se ha podido guardar el usuario');
			}
		});

	}

	function getUsuario() {
		$.ajax({
			url : '/admin/usuario?token=' + $('#token').val(),
			method : 'GET',
			success : function(response) {
				$('#username').val(response.username);
				$('#password').val(response.password);
			},
			error : function() {
				alert('Error inesperado');
			}
		});
	}

	getArbitro();
	getUsuario();
	getPartidosArbitro();

