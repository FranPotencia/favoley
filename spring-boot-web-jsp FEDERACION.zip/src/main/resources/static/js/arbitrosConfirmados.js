
	$('#listaNavegadorAdministrador').addClass("activeVerde")
	var tablaArbitros = $('#tablaArbitros').DataTable({"paging" : true, "responsive" : true,"ordering":false,"pageLength" : 5,
		"lengthChange": false,"info": false,"columns": [
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false }
		  ],"language": {
	            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	        }});
	function getArbitrosConfirmados() {
		$.ajax({
			url : '/admin/getArbitrosConfirmados?token=' + $("#token").val(),
			method : 'GET',
			success : function(response) { //response manda una tabla con equipos

				for (var i = 0; i < response.length; i++) {
					
					var rowNode = tablaArbitros
				    .row.add( [ response[i].nombre, response[i].apellidos, response[i].delegacion,
				    	response[i].licencia,response[i].numeroLicencia,response[i].email] )
				    .draw()
				    .node();
				}
				// 
			},
			error : function() {
				alert('Error inesperado');
			}
		});
	}

	getArbitrosConfirmados();
