
	$('#listaNavegadorAdministrador').addClass("activeVerde")
	var tablaArbitros = $('#tablaArbitros').DataTable({"paging" : true, "responsive" : true,"pageLength" : 5,
		"lengthChange": false,"info": false,"ordering":false,"columns": [
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false }
		  ],"language": {
	            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	        }});
	function getArbitros() {
		$.ajax({
			url : '/admin/getArbitros?token='+$('#token').val(),
			method : 'GET',
			success : function(response) { //response manda una tabla con equipos

				for (var i = 0; i < response.length; i++) {
					var rowNode = tablaArbitros
				    .row.add( [ response[i].nombre, response[i].apellidos, 
				    	response[i].delegacion,response[i].licencia,response[i].numeroLicencia,response[i].email,
					'<button type="button" onclick="editarArbitro(\''+response[i].id+'\')" '
						+'  class="btn btn-info btn-sm">Ver detalles</button>'] )
				    .draw()
				    .node();
				}
// 
			},
			error : function() {
				alert('Error inesperado');
			}
		});
	}
	function editarArbitro(id){
		location.href='/admin/arbitro/'+id+'?token='+$("#token").val();
	}
	getArbitros();
