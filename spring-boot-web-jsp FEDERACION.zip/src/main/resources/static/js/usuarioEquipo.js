$('#listaNavegadorAdministrador').addClass("activeVerde"); // Para que en el
															// navegador
															// aparezca activo
															// esta secci�n

var tablaPartidos = $('#tablaPartidos').DataTable({
	"paging" : true,
	"responsive" : true,
	"lengthChange" : false,
	"info" : false,
	"pageLength":5,
	"searching" : true,
	"ordering" : false,
	"columns" : [ {
		"orderable" : false
	}, {
		"orderable" : false
	}, {
		"orderable" : false
	}, {
		"orderable" : false
	}

	],
	"language" : {
		"url" : "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	}
});

function postUsuario() {

	var usuario = {
		"username" : $('#username').val(),
		"password" : $('#password').val()
	};

	$.ajax({
		url : '/admin/cambiarPassword?token=' + $('#token').val(),
		method : 'POST',
		data : JSON.stringify(usuario),
		"headers" : {
			"Content-Type" : "application/json"
		},
		success : function(response) {
			$('#username').val(response.username);
			$('#password').val(response.password);
			alert('Contrase�a actualizada');
		},
		error : function() {
			alert('No se ha podido guardar el usuario');
		}
	});

}

function getUsuario() {
	$.ajax({
		url : '/admin/usuario?token=' + $('#token').val(),
		method : 'GET',
		success : function(response) {
			$('#username').val(response.username);
			$('#password').val(response.password);
		},
		error : function() {
			alert('Error inesperado');
		}
	});
}

function getPartidosEquipo() {
	$.ajax({
		url : '/admin/getPartidosEquipo/?token='
				+ $('#token').val(),
		method : 'GET',
		success : function(response) {
			if(response!=null && response.length>0){
				for (var i = 0; i < response.length; i++) {
					var rowNode = tablaPartidos
				    .row.add( [ response[i].local, response[i].visitante, response[i].fecha,
				    	response[i].resultado] )
				    .draw()
				    .node();
				}
			}
			
		},
		error : function(response) {
			alert('Ha ocurrido un error')
		}
	});
}

getUsuario();
getPartidosEquipo();