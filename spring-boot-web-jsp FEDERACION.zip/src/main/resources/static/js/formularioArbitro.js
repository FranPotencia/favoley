
	$('#listaNavegadorArbitro').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n
	
	
	function postArbitro() {

		
			if($('#nombre').val()==''){
				alert('Falta nombre');
				return ;
			}
			if($('#apellidos').val()==''){
				alert('Falta apellidos');
				return ;
			}
			if($('#dni').val()==''){
				alert('Falta dni');
				return ;
			}
			if($('#fechaNacimiento').val()==''){
				alert('Falta fecha de nacimiento');
				return ;
			}
			if($('#localidad').val()==''){
				alert('Falta localidad');
				return ;
			}
			if($('#provincia').val()==''){
				alert('Falta provincia');
				return ;
			}
			if($('#email').val()==''){
				alert('Falta email');
				return ;
			}
			if($('#movil').val()==''){
				alert('Falta movil');
				return ;
			}
			if($('#delegacion').val()==''){
				alert('Falta delegacion');
				return ;
			}
			if($('#licencia').val()==''){
				alert('Falta licencia');
				return ;
			}
			if($('#numeroLicencia').val()==''){
				alert('Falta numeroLicencia');
				return ;
			}
			var arbitro = {
				"nombre" : $('#nombre').val(),
				"apellidos" : $('#apellidos').val(),
				"dni" : $('#dni').val(),
				"fechaNacimiento" : $('#fechaNacimiento').val(),
				"localidad" : $('#localidad').val(),
				"provincia" : $('#provincia').val(),
				"email" : $('#email').val(),
				"movil" : $('#movil').val(),
				"delegacion" : $('#delegacion').val(),
				"licencia" : $('#licencia').val(),
				"numeroLicencia" : $('#numeroLicencia').val()
			}
		

		$.ajax({
			url : '/guardarArbitro',
			method : 'POST',
			data : JSON.stringify(arbitro),
			"headers" : {
				"Content-Type" : "application/json"
			},
			success : function(response) {
				location.href = "/";
			},
			error : function() {
				alert('No se ha podido guardar el �rbitro');
			}
		});

	}
	
