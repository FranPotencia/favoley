
	
	$('#listaNavegadorAdministrador').addClass("activeVerde"); //Para que en el navegador aparezca activo esta secci�n
   
	
	function postEquipo() {

		$.ajax({
			url : '/admin/aceptarEquipo/'+$('#idEquipo').val()+'?token='+$('#token').val(),
			method : 'POST',
			//data : JSON.stringify(equipo), No se lo mando, ya que el equipo ya se encuentra en la base de datos, s�lo necesita el id que le mando por la url
			"headers" : {
				"Content-Type" : "application/json"
			},
			success : function(response) {
				location.href = "/admin/equipos?token="+$('#token').val();
			},
			error : function() {
				alert('No se ha podido guardar el equipo');
			}
		});

	}
	
	var tablaJugadores = $('#tablaJugadores').DataTable({"paging" : false, "responsive" : true,"pageLength" : 5,
		"lengthChange": false,"info": false,"ordering":false,"columns": [
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false },
		    { "orderable": false, "width":"20%" }
		  ],"language": {
	            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
	        }});
	
	//Jugadores ya existentes
	function addJugadorReal(response) {
		var rowNode = tablaJugadores
	    .row.add( [ response.nombre, response.apellidos, 
	    	response.dni,response.fechaNacimientoFormateada ] )
	    .draw()
	    .node();
	}
	

	
	function getEquipo(){
		if($('#idEquipo').val()!=''){
			$.ajax({
				url : '/admin/getEquipo/'+$('#idEquipo').val()+'?token='+$('#token').val(),
				method : 'GET',
				success : function(response) {
					$('#nombreEquipo').val(response.nombreEquipo);
					$('#localidad').val(response.localidad);
					$('#provincia').val(response.provincia);
					$('#direccion').val(response.direccion);
					$('#pabellon').val(response.pabellon);
					$('#email').val(response.email);
					$('#movil').val(response.movil);
					$('#primerEntrenador').val(response.primerEntrenador);
					
					//Cuando muestro un equipo, a�ado a la vista todos los jugadores que pertenecen a un equipo, llamando a la funci�n addJugadorReal
					for (var i = 0; i < response.jugadores.length; i++) {
						addJugadorReal(response.jugadores[i]);
					}
				},
				error : function() {
					alert('Error inesperado');
				}
			});
		}
		
	}
	
	function deleteEquipo(id){
		$.ajax({
			url : '/admin/deleteEquipo/'+id+'?token='+$('#token').val(),
			method:'DELETE',
			success : function(response) {
				location.href = "/admin/equipos?token="+$('#token').val();
			},
			error: function(response) {
				alert('Ha ocurrido un error')
			}
		});
	}
	
	getEquipo();

