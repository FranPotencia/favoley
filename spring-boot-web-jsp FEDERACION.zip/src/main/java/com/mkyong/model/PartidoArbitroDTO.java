package com.mkyong.model;

public class PartidoArbitroDTO {

	private Long numeroPartido;
	private String equipoLocal;
	private String equipoVisitante;
	private String pabellon;
	private String set1;
	private String set2;
	private String set3;
	private String set4;
	private String set5;
	private String resultado;

	public String getPabellon() {
		return pabellon;
	}

	public void setPabellon(String pabellon) {
		this.pabellon = pabellon;
	}

	public Long getNumeroPartido() {
		return numeroPartido;
	}

	public void setNumeroPartido(Long numeroPartido) {
		this.numeroPartido = numeroPartido;
	}

	public String getEquipoLocal() {
		return equipoLocal;
	}

	public void setEquipoLocal(String equipoLocal) {
		this.equipoLocal = equipoLocal;
	}

	public String getEquipoVisitante() {
		return equipoVisitante;
	}

	public void setEquipoVisitante(String equipoVisitante) {
		this.equipoVisitante = equipoVisitante;
	}

	public String getSet1() {
		return set1;
	}

	public void setSet1(String set1) {
		this.set1 = set1;
	}

	public String getSet2() {
		return set2;
	}

	public void setSet2(String set2) {
		this.set2 = set2;
	}

	public String getSet3() {
		return set3;
	}

	public void setSet3(String set3) {
		this.set3 = set3;
	}

	public String getSet4() {
		return set4;
	}

	public void setSet4(String set4) {
		this.set4 = set4;
	}

	public String getSet5() {
		return set5;
	}

	public void setSet5(String set5) {
		this.set5 = set5;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

}
