package es.uhu.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.uhu.model.JugadorActualizado;
import es.uhu.model.JugadorConfirmado;
import es.uhu.repository.JugadorActualizadoDAO;
import es.uhu.repository.JugadorConfirmadoDAO;

@Service
public class JugadorActualizadoService {

	@Autowired
	private JugadorActualizadoDAO jugadorActualizadoDAO;
	
	private DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	
	/*
	public List<Jugador> getAllJugadores(){ 

		List<Jugador> listaJugadores=new ArrayList<Jugador>();
		
		listaJugadores=jugadorDAO.findAll();
		
		if(!CollectionUtils.isEmpty(listaJugadores)) {
			for (Jugador jugador : listaJugadores) {
				String strDate = dateFormat.format(jugador.getFechaNacimiento()); 
				jugador.setFechaNacimientoFormateada(strDate);
			}
		}
		
		return listaJugadores;
	}
	
	*/
	
	/*
	public Jugador guardarJugador(Jugador jugador) {
		jugador=jugadorDAO.save(jugador);
		String strDate = dateFormat.format(jugador.getFechaNacimiento()); 
		jugador.setFechaNacimientoFormateada(strDate);
		return jugadorDAO.save(jugador);
	}
	*/
	
	public void guardarJugadores(List<JugadorActualizado> jugadores) {
		jugadorActualizadoDAO.save(jugadores);
	}
	
	public void deleteJugador(Long id) {
		jugadorActualizadoDAO.delete(id);
	}
	
}
