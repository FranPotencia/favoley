package es.uhu.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

@Service
public class JasperService {

	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private TokenService tokenService;
	
	public ResponseEntity<Resource> getDocumentacionEquipo(String token)
			throws SQLException, JRException, IOException {
		// Ruta del .jasper se creará donde se esté ejecutando la aplicacion, no debes hacer nada.
		// si eso ponle otro nombre al jasper
		File jasperFile=new File("equipo.jasper");
		
		// Estas tres lineas son la creacion del mapa de parametros, el cual ya le paso el parametro del id del equipo
		// y la conexion a la base de datos para pasar a .fillReport despues. Aqui no toques nada
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("id",tokenService.getIdAccesoToken(token));
		Connection con=dataSource.getConnection();
		
		// Aqui se ejecuta, en base a los parametros que le pases y la conexion, el jasper. No tienes que tocar nada.
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperFile.getPath(), parameters,con);
		// Despues de haberse ejecutado debes exportarlo al formato que quieras, en este caso decidimos PDF. 
		JasperExportManager.exportReportToPdfFile(jasperPrint, "equipo.pdf");
		File filePdf = new File("equipo.pdf");
		
		// aqui lo que hace es convertir el fichero a bytes y contruir una respuesta http para devolverlo por el navegador
		// pudiendose realizar la descarga
		Path path = Paths.get(filePdf.getAbsolutePath());
		ByteArrayResource resourceDownload = new ByteArrayResource(Files.readAllBytes(path));
		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=equipo.pdf");
		header.add("Cache-Control", "no-cache, no-store, must-revalidate");
		header.add("Pragma", "no-cache");
		header.add("Expires", "0");
		Long length=filePdf.length();
		// Cuando ya se ha construido la respuesta http puedes borrar el pdf generado en el directorio del servidor.
		filePdf.delete();
		
		// Esta es la forma de escupir la respuesta http construida
		return ResponseEntity.ok()
		        .headers(header)
		        .contentType(MediaType.parseMediaType("application/pdf"))
		        .contentLength(length) 
		        .body(resourceDownload);
	}
}
