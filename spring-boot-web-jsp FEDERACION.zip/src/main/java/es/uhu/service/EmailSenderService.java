package es.uhu.service;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

import es.uhu.model.Usuario;

@Service
public class EmailSenderService {


	public void sendEmailEquipo(Usuario usuario) throws Exception {

		Session session = getSesion();
		try {

	        Message message = new MimeMessage(session);
	        message.setFrom(new InternetAddress("favbtest@gmail.com"));
	        message.setRecipients(Message.RecipientType.TO,
	                InternetAddress.parse(usuario.getUsername()));
	        message.setSubject("Resolución equipo FAVB");
	        message.setText("Buenas, hemos resuelto su solicitud del equipo. "
					+ "Podrá acceder al portal telemático y comprobar su información. Usuario: " + usuario.getUsername()
					+ " Contraseña: " + usuario.getUsername());

	        Transport.send(message);

	    } catch (MessagingException e) {
	        throw new RuntimeException(e);
	    }
	}
	public void sendEmailArbitro(Usuario usuario) throws Exception {
		Session session = getSesion();
		try {
			
	        Message message = new MimeMessage(session);
	        message.setFrom(new InternetAddress("favbtest@gmail.com"));
	        message.setRecipients(Message.RecipientType.TO,
	                InternetAddress.parse(usuario.getUsername()));
	        message.setSubject("Resolución árbitro FAVB");
	        message.setText("Buenas, hemos resuelto su solicitud de árbitro. "
					+ "Podrá acceder al portal telemático y comprobar su información. Usuario: " + usuario.getUsername()
					+ " Contraseña: " + usuario.getUsername());

	        Transport.send(message);

	    } catch (MessagingException e) {
	        throw new RuntimeException(e);
	    }
	}
	private Session getSesion() {
		Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class",
            "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "465"); 
        Session session = Session.getDefaultInstance(props,
        new javax.mail.Authenticator() {
                            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("favbtest@gmail.com","favbtest123456");
            }
        });
		return session;
	}
}