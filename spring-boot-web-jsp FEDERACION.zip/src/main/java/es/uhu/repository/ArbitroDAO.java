package es.uhu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import es.uhu.model.Arbitro;

@Repository
public interface ArbitroDAO extends JpaRepository<Arbitro, Long> {

}
