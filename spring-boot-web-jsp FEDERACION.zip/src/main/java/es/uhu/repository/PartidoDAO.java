package es.uhu.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import es.uhu.model.Jornada;
import es.uhu.model.Partido;


@Repository
public interface PartidoDAO extends JpaRepository<Partido, Long> {

	void deleteByJornada(Jornada jornada);
	
	Partido findByNumeroPartido(Long numeroPartido);
	
	List<Partido> findByIdArbitro(Long idArbitro);
}
