package es.uhu.repository;

import org.springframework.stereotype.Repository;

import es.uhu.model.Jugador;
import es.uhu.model.JugadorActualizado;
import es.uhu.model.JugadorConfirmado;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface JugadorActualizadoDAO extends JpaRepository<JugadorActualizado, Long> {// <nombre tabla, id>  Esto es la api de persistencia de java para la tabla EQUIPO
	
}