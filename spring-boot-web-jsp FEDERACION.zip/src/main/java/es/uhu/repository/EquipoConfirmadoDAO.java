package es.uhu.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import es.uhu.model.EquipoConfirmado;

	@Repository
	public interface EquipoConfirmadoDAO extends JpaRepository<EquipoConfirmado, Long> { // Esto es la api de persistencia de java para la tabla EQUIPO
		
	}
	

