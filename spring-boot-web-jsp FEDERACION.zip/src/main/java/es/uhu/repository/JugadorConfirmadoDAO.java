package es.uhu.repository;

import org.springframework.stereotype.Repository;

import es.uhu.model.EquipoConfirmado;
import es.uhu.model.Jugador;
import es.uhu.model.JugadorConfirmado;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface JugadorConfirmadoDAO extends JpaRepository<JugadorConfirmado, Long> {// <nombre tabla, id>  Esto es la api de persistencia de java para la tabla EQUIPO
	
	void deleteByEquipo(EquipoConfirmado equipo);
}